import { useState, useEffect } from 'react';
import { STAFF as INITIAL_STAFF, StaffMember } from './mockData';

// Simple in-memory store with event listeners for the mockup
// This ensures state is shared across pages without a backend
const listeners = new Set<(staff: StaffMember[]) => void>();

// Initialize state from localStorage if available, otherwise use mock data
const loadState = (): StaffMember[] => {
  try {
    const saved = localStorage.getItem('medisched-staff');
    if (saved) {
      return JSON.parse(saved);
    }
  } catch (e) {
    console.error('Failed to load state from localStorage', e);
  }
  return [...INITIAL_STAFF];
};

let currentStaff = loadState();

const saveState = (staff: StaffMember[]) => {
  try {
    localStorage.setItem('medisched-staff', JSON.stringify(staff));
  } catch (e) {
    console.error('Failed to save state to localStorage', e);
  }
};

export const useStaff = () => {
  const [staff, setStaff] = useState<StaffMember[]>(currentStaff);

  useEffect(() => {
    const handler = (newStaff: StaffMember[]) => setStaff(newStaff);
    listeners.add(handler);
    return () => { listeners.delete(handler); };
  }, []);

  const updateStaffMember = (updatedMember: StaffMember) => {
    const newStaff = currentStaff.map(s => s.id === updatedMember.id ? updatedMember : s);
    currentStaff = newStaff;
    saveState(newStaff);
    listeners.forEach(l => l(newStaff));
  };

  const addStaffMember = (member: StaffMember) => {
    const newStaff = [...currentStaff, member];
    currentStaff = newStaff;
    saveState(newStaff);
    listeners.forEach(l => l(newStaff));
  };

  const deleteStaffMember = (id: string) => {
    const newStaff = currentStaff.filter(s => s.id !== id);
    currentStaff = newStaff;
    saveState(newStaff);
    listeners.forEach(l => l(newStaff));
  };
  
  const setAllStaff = (newStaff: StaffMember[]) => {
      currentStaff = newStaff;
      saveState(newStaff);
      listeners.forEach(l => l(newStaff));
  };

  return { staff, updateStaffMember, addStaffMember, deleteStaffMember, setAllStaff };
};
