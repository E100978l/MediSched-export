export type StaffType = 'MD' | 'DO' | 'NP' | 'PA' | 'LVN' | 'RN';
export type Specialty = 
  | 'Internal/Family Med (Met Home 1)' 
  | 'Internal/Family Med (Met Home 2)' 
  | 'OB/GYN' 
  | 'Pediatrics' 
  | 'Allergy' 
  | 'Optometry' 
  | 'Diabetic Education';

export interface StaffMember {
  id: string;
  name: string;
  role: StaffType;
  specialty: Specialty;
  crossTrained?: Specialty[]; // Only for LVNs
  assignedTo?: string[]; // Array of Provider IDs if LVN
}

export interface ProviderSchedule {
  providerId: string;
  date: string;
  am: 'Patient Care' | 'Admin' | 'Off' | 'Meeting';
  pm: 'Patient Care' | 'Admin' | 'Off' | 'Meeting';
}

// Mock Data Generation
export const SPECIALTIES: Specialty[] = [
  'Internal/Family Med (Met Home 1)',
  'Internal/Family Med (Met Home 2)',
  'OB/GYN',
  'Pediatrics',
  'Allergy',
  'Optometry',
  'Diabetic Education'
];

export const STAFF: StaffMember[] = [
  // Met Home 1 Providers
  { id: 'p1', name: 'Dr. Sarah Miller', role: 'MD', specialty: 'Internal/Family Med (Met Home 1)' },
  { id: 'p2', name: 'Dr. James Chen', role: 'MD', specialty: 'Internal/Family Med (Met Home 1)' },
  { id: 'p3', name: 'Dr. Emily Davis', role: 'MD', specialty: 'Internal/Family Med (Met Home 1)' },
  { id: 'p4', name: 'NP Mark Wilson', role: 'NP', specialty: 'Internal/Family Med (Met Home 1)' },
  
  // Met Home 2 Providers
  { id: 'p5', name: 'Dr. Robert Taylor', role: 'MD', specialty: 'Internal/Family Med (Met Home 2)' },
  { id: 'p6', name: 'Dr. Lisa Anderson', role: 'MD', specialty: 'Internal/Family Med (Met Home 2)' },
  { id: 'p7', name: 'PA David Martinez', role: 'PA', specialty: 'Internal/Family Med (Met Home 2)' },
  { id: 'p8', name: 'Dr. Jennifer White', role: 'MD', specialty: 'Internal/Family Med (Met Home 2)' },

  // OB/GYN
  { id: 'p9', name: 'Dr. Amanda Thomas', role: 'MD', specialty: 'OB/GYN' },
  { id: 'p10', name: 'Dr. Christopher Lee', role: 'MD', specialty: 'OB/GYN' },

  // Pediatrics
  { id: 'p11', name: 'Dr. Patricia Moore', role: 'MD', specialty: 'Pediatrics' },
  { id: 'p12', name: 'NP Kevin Jackson', role: 'NP', specialty: 'Pediatrics' },

  // Allergy
  { id: 'p13', name: 'Dr. Elizabeth Harris', role: 'MD', specialty: 'Allergy' },

  // Optometry
  { id: 'p14', name: 'Dr. Brian Clark', role: 'MD', specialty: 'Optometry' },

  // Diabetic Education Providers (Assuming providers exist for this specialty too, or LVN supports others)
  // Adding a diabetic education provider for context
  { id: 'p15', name: 'Dr. Susan Lewis', role: 'MD', specialty: 'Diabetic Education' },
  { id: 'p16', name: 'NP Alan Grant', role: 'NP', specialty: 'Diabetic Education' },


  // LVNs
  // Met Home 1 - 1:1 typically
  { id: 'l1', name: 'LVN Jessica Hall', role: 'LVN', specialty: 'Internal/Family Med (Met Home 1)', crossTrained: ['Internal/Family Med (Met Home 2)', 'Pediatrics'], assignedTo: ['p1'] },
  { id: 'l2', name: 'LVN Daniel Young', role: 'LVN', specialty: 'Internal/Family Med (Met Home 1)', crossTrained: ['Internal/Family Med (Met Home 2)'], assignedTo: ['p2'] },
  
  // Met Home 2 - 1:1 typically
  { id: 'l3', name: 'LVN Ashley King', role: 'LVN', specialty: 'Internal/Family Med (Met Home 2)', crossTrained: ['Internal/Family Med (Met Home 1)', 'OB/GYN'], assignedTo: ['p5'] },
  { id: 'l6', name: 'LVN Ryan Baker', role: 'LVN', specialty: 'Internal/Family Med (Met Home 2)', crossTrained: [], assignedTo: ['p6'] },

  // Pediatrics - Many LVNs to One Provider example
  // Assigning l4 and l9 to p11 (Dr. Moore)
  { id: 'l4', name: 'LVN Matthew Scott', role: 'LVN', specialty: 'Pediatrics', crossTrained: ['Allergy'], assignedTo: ['p11'] },
  { id: 'l9', name: 'LVN Sarah Connor', role: 'LVN', specialty: 'Pediatrics', crossTrained: [], assignedTo: ['p11'] }, 
  
  // OB/GYN - Many LVNs to One Provider example
  { id: 'l5', name: 'LVN Olivia Green', role: 'LVN', specialty: 'OB/GYN', crossTrained: ['Internal/Family Med (Met Home 1)'], assignedTo: ['p9'] },
  { id: 'l10', name: 'LVN Nancy Drew', role: 'LVN', specialty: 'OB/GYN', crossTrained: [], assignedTo: ['p9'] },

  // Diabetic Education - One LVN to Many Providers example
  // Assigning l11 to both p15 and p16
  { id: 'l11', name: 'LVN Clara Barton', role: 'LVN', specialty: 'Diabetic Education', crossTrained: ['Internal/Family Med (Met Home 1)'], assignedTo: ['p15', 'p16'] },

  // Allergy
  { id: 'l7', name: 'LVN Emma Hill', role: 'LVN', specialty: 'Allergy', crossTrained: ['Pediatrics'], assignedTo: ['p13'] },
  
  // Optometry
  { id: 'l8', name: 'LVN Noah Carter', role: 'LVN', specialty: 'Optometry', crossTrained: [], assignedTo: ['p14'] },
  
  // RNs (The 4 Charge Nurses)
  { id: 'r1', name: 'RN Charge Michael Brown', role: 'RN', specialty: 'Internal/Family Med (Met Home 1)' },
  { id: 'r2', name: 'RN Charge Karen Wilson', role: 'RN', specialty: 'Internal/Family Med (Met Home 2)' },
  { id: 'r3', name: 'RN Charge Sarah Johnson', role: 'RN', specialty: 'Pediatrics' },
  { id: 'r4', name: 'RN Charge David Lee', role: 'RN', specialty: 'OB/GYN' },
];

export const SCHEDULE_TYPES = ['Patient Care', 'Admin', 'Off', 'Meeting'];
