import { useState, useMemo } from "react";
import { AppLayout } from "@/components/layout/AppLayout";
import { useStaff } from "@/lib/store";
import { SPECIALTIES, StaffMember, StaffType, Specialty } from "@/lib/mockData";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { ChevronLeft, ChevronRight, Calendar as CalendarIcon, Filter, Syringe, Eye, AlertCircle, UserCog, Check, Edit2 } from "lucide-react";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { format, addDays, startOfWeek, startOfMonth, endOfMonth, eachDayOfInterval, isSameDay } from "date-fns";

// Types for our local schedule state
interface AssignmentState {
  lvnId: string;
  status: 'Active' | 'Sick' | 'Vacation';
  clinicAssignment?: 'Flu Clinic' | 'Retinal AI' | null;
  coveringLvnId?: string | null;
}

interface ProviderDayState {
  providerId: string;
  date: string; // ISO date string
  am: 'Patient Care' | 'Admin' | 'Off' | 'Meeting';
  pm: 'Patient Care' | 'Admin' | 'Off' | 'Meeting';
  assignments: AssignmentState[];
}

// Helper to generate initial state
const generateInitialMonthState = (year: number, month: number, staff: StaffMember[]) => {
  const startDate = startOfMonth(new Date(year, month));
  const endDate = endOfMonth(startDate);
  const days = eachDayOfInterval({ start: startDate, end: endDate });
  
  const state: Record<string, ProviderDayState> = {};

  days.forEach(day => {
    const dateStr = format(day, 'yyyy-MM-dd');
    const providers = staff.filter(s => ['MD', 'DO', 'NP', 'PA'].includes(s.role));
    
    providers.forEach(provider => {
      const key = `${provider.id}-${dateStr}`;
      const assignedLvns = staff.filter(s => s.assignedTo && s.assignedTo.includes(provider.id));
      
      // Basic random generation to populate the view
      const assignments = assignedLvns.map(lvn => ({
        lvnId: lvn.id,
        status: 'Active' as const,
        clinicAssignment: null
      }));

      state[key] = {
        providerId: provider.id,
        date: dateStr,
        am: Math.random() > 0.2 ? 'Patient Care' : 'Off',
        pm: Math.random() > 0.2 ? 'Patient Care' : 'Off',
        assignments
      };
    });
  });

  return state;
};

export default function Schedule() {
  const { staff, updateStaffMember } = useStaff();
  const [date, setDate] = useState(new Date());
  const [viewMode, setViewMode] = useState<'day' | 'month'>('day');
  const [selectedSpecialty, setSelectedSpecialty] = useState<string>("all");
  
  // Main Schedule State
  const [scheduleState, setScheduleState] = useState<Record<string, ProviderDayState>>(() => 
    generateInitialMonthState(date.getFullYear(), date.getMonth(), staff)
  );

  // Edit Schedule State
  const [editingSlot, setEditingSlot] = useState<{providerId: string, date: string} | null>(null);
  const [editAm, setEditAm] = useState<string>("");
  const [editPm, setEditPm] = useState<string>("");
  const [editAssignments, setEditAssignments] = useState<AssignmentState[]>([]);

  // Edit Staff Name/Specialty State (Pencil Icon)
  const [editingStaffId, setEditingStaffId] = useState<string | null>(null);
  const [editStaffName, setEditStaffName] = useState("");
  const [editStaffSpecialty, setEditStaffSpecialty] = useState<Specialty>(SPECIALTIES[0]);

  const handleDateChange = (days: number) => {
    setDate(prev => addDays(prev, days));
  };

  const currentDayState = useMemo(() => {
    const dateStr = format(date, 'yyyy-MM-dd');
    const providers = staff.filter(s => ['MD', 'DO', 'NP', 'PA'].includes(s.role));
    
    // Filter by specialty
    const filteredProviders = selectedSpecialty === 'all' 
      ? providers 
      : providers.filter(p => p.specialty === selectedSpecialty);

    return filteredProviders.map(provider => {
      const key = `${provider.id}-${dateStr}`;
      // Fallback if state doesn't exist for this day (e.g. changed months or new staff)
      return scheduleState[key] || {
        providerId: provider.id,
        date: dateStr,
        am: 'Off',
        pm: 'Off',
        assignments: staff.filter(s => s.assignedTo?.includes(provider.id)).map(lvn => ({
            lvnId: lvn.id,
            status: 'Active',
            clinicAssignment: null
        }))
      };
    });
  }, [date, scheduleState, selectedSpecialty, staff]);

  // ... (rest of edit schedule logic)
  const handleEditClick = (providerId: string, dateStr: string) => {
    const key = `${providerId}-${dateStr}`;
    const current = scheduleState[key];
    if (current) {
      setEditingSlot({ providerId, date: dateStr });
      setEditAm(current.am);
      setEditPm(current.pm);
      setEditAssignments(current.assignments.map(a => ({...a})));
    }
  };

  const handleSaveEdit = () => {
    if (editingSlot) {
      const key = `${editingSlot.providerId}-${editingSlot.date}`;
      setScheduleState(prev => ({
        ...prev,
        [key]: {
          ...prev[key],
          am: editAm as any,
          pm: editPm as any,
          assignments: editAssignments
        }
      }));
      setEditingSlot(null);
    }
  };

  const updateAssignment = (lvnId: string, updates: Partial<AssignmentState>) => {
    setEditAssignments(prev => prev.map(a => 
      a.lvnId === lvnId ? { ...a, ...updates } : a
    ));
  };

  // Staff Edit Logic
  const handleStaffEditClick = (e: React.MouseEvent, id: string) => {
    e.stopPropagation(); // Prevent opening schedule edit
    const member = staff.find(s => s.id === id);
    if (member) {
      setEditingStaffId(id);
      setEditStaffName(member.name);
      setEditStaffSpecialty(member.specialty);
    }
  };

  const handleStaffSave = () => {
    if (editingStaffId && editStaffName.trim()) {
      const member = staff.find(s => s.id === editingStaffId);
      if (member) {
        updateStaffMember({ ...member, name: editStaffName, specialty: editStaffSpecialty });
      }
      setEditingStaffId(null);
    }
  };

  // Month View Helpers
  const monthDays = useMemo(() => {
    return eachDayOfInterval({
      start: startOfMonth(date),
      end: endOfMonth(date)
    });
  }, [date]);

  const getProviderName = (id: string) => staff.find(s => s.id === id)?.name || id;
  const getLvnName = (id: string) => staff.find(s => s.id === id)?.name || id;

  return (
    <AppLayout>
      <div className="p-8 space-y-6 max-w-[1600px] mx-auto">
        {/* ... Header ... */}
        <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
          <div>
            <h2 className="text-3xl font-bold tracking-tight font-heading text-foreground">Schedule Management</h2>
            <p className="text-muted-foreground mt-1">
              Manage provider shifts and staff assignments.
            </p>
          </div>
          
          <div className="flex items-center gap-4">
            <Tabs value={viewMode} onValueChange={(v) => setViewMode(v as 'day' | 'month')}>
              <TabsList>
                <TabsTrigger value="day">Day View</TabsTrigger>
                <TabsTrigger value="month">Month View</TabsTrigger>
              </TabsList>
            </Tabs>

            <div className="flex items-center gap-2 bg-card p-1 rounded-lg border border-border shadow-sm">
              <Button variant="ghost" size="icon" onClick={() => handleDateChange(viewMode === 'day' ? -1 : -30)}>
                <ChevronLeft className="h-4 w-4" />
              </Button>
              <div className="flex items-center gap-2 px-4 font-medium min-w-[140px] justify-center">
                <CalendarIcon className="h-4 w-4 text-muted-foreground" />
                {viewMode === 'day' 
                  ? format(date, 'MMM d, yyyy')
                  : format(date, 'MMMM yyyy')
                }
              </div>
              <Button variant="ghost" size="icon" onClick={() => handleDateChange(viewMode === 'day' ? 1 : 30)}>
                <ChevronRight className="h-4 w-4" />
              </Button>
            </div>
          </div>
        </div>

        <div className="flex items-center gap-4">
           <Select value={selectedSpecialty} onValueChange={setSelectedSpecialty}>
            <SelectTrigger className="w-[280px]">
              <Filter className="w-4 h-4 mr-2 text-muted-foreground" />
              <SelectValue placeholder="Filter by Specialty" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Specialties</SelectItem>
              {SPECIALTIES.map(s => (
                <SelectItem key={s} value={s}>{s}</SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        {viewMode === 'day' ? (
          <div className="border border-border rounded-lg overflow-hidden bg-card shadow-sm">
            <div className="grid grid-cols-[250px_250px_1fr_1fr] bg-muted/50 divide-x divide-border border-b border-border">
              <div className="p-4 font-medium text-sm text-muted-foreground">Provider</div>
              <div className="p-4 font-medium text-sm text-muted-foreground">Assigned Staff</div>
              <div className="p-4 font-medium text-sm text-muted-foreground text-center">AM (08:00 - 12:00)</div>
              <div className="p-4 font-medium text-sm text-muted-foreground text-center">PM (13:00 - 17:00)</div>
            </div>

            <div className="divide-y divide-border">
              {currentDayState.map((row) => (
                <div key={row.providerId} className="grid grid-cols-[250px_250px_1fr_1fr] divide-x divide-border hover:bg-accent/5 transition-colors group">
                  {/* Provider Column */}
                  <div className="p-4 flex flex-col justify-center relative group/provider">
                    <div className="flex items-center justify-between">
                        <div className="font-medium text-foreground">{getProviderName(row.providerId)}</div>
                        <Button 
                            variant="ghost" 
                            size="icon" 
                            className="h-6 w-6 opacity-0 group-hover/provider:opacity-100 transition-opacity"
                            onClick={(e) => handleStaffEditClick(e, row.providerId)}
                        >
                            <Edit2 className="h-3 w-3" />
                        </Button>
                    </div>
                    <div className="text-xs text-muted-foreground truncate">
                        {staff.find(s => s.id === row.providerId)?.specialty}
                    </div>
                  </div>

                  {/* Staff Assignment */}
                  <div className="p-4 flex flex-col justify-center gap-2">
                    {row.assignments.length > 0 ? (
                      row.assignments.map((assignment, idx) => (
                          <div key={assignment.lvnId} className="flex flex-col gap-1 group/lvn">
                            <div className={`flex items-center gap-2 p-2 rounded-md border shadow-xs transition-all
                              ${assignment.status !== 'Active' 
                                ? 'border-red-200 bg-red-50 opacity-80' 
                                : assignment.clinicAssignment 
                                  ? 'border-orange-200 bg-orange-50' 
                                  : 'border-border bg-background'}`}>
                              
                              <div className={`w-6 h-6 rounded-full flex items-center justify-center text-xs font-bold shrink-0
                                ${assignment.status !== 'Active' 
                                  ? 'bg-red-100 text-red-700'
                                  : assignment.clinicAssignment 
                                    ? 'bg-orange-100 text-orange-700' 
                                    : 'bg-indigo-100 text-indigo-700'}`}>
                                L
                              </div>
                              
                              <div className="flex-1 min-w-0">
                                <div className="flex justify-between items-center">
                                  <div className={`text-sm font-medium truncate ${assignment.status !== 'Active' ? 'line-through text-muted-foreground' : ''}`}>
                                    {getLvnName(assignment.lvnId)}
                                  </div>
                                  <Button 
                                      variant="ghost" 
                                      size="icon" 
                                      className="h-5 w-5 opacity-0 group-hover/lvn:opacity-100 transition-opacity"
                                      onClick={(e) => handleStaffEditClick(e, assignment.lvnId)}
                                  >
                                      <Edit2 className="h-3 w-3" />
                                  </Button>
                                </div>
                              </div>
                            </div>
                          </div>
                      ))
                    ) : (
                      <div className="text-sm text-muted-foreground italic px-2">No assignment</div>
                    )}
                  </div>

                  {/* AM Shift */}
                  <div className="p-2 cursor-pointer" onClick={() => handleEditClick(row.providerId, row.date)}>
                    <div className={`h-full rounded-md border flex items-center justify-center text-sm font-medium transition-all hover:ring-2 hover:ring-primary/20
                      ${row.am === 'Patient Care' ? 'bg-primary/10 border-primary/20 text-primary' : 'bg-secondary/50 border-transparent text-muted-foreground'}`}>
                      {row.am}
                    </div>
                  </div>

                  {/* PM Shift */}
                  <div className="p-2 cursor-pointer" onClick={() => handleEditClick(row.providerId, row.date)}>
                    <div className={`h-full rounded-md border flex items-center justify-center text-sm font-medium transition-all hover:ring-2 hover:ring-primary/20
                      ${row.pm === 'Patient Care' ? 'bg-primary/10 border-primary/20 text-primary' : 'bg-secondary/50 border-transparent text-muted-foreground'}`}>
                      {row.pm}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        ) : (
          // MONTH VIEW
          <div className="border border-border rounded-lg overflow-x-auto bg-card shadow-sm">
             <table className="w-full border-collapse">
               <thead>
                 <tr>
                   <th className="sticky left-0 z-10 bg-muted/90 p-4 text-left text-sm font-medium text-muted-foreground border-b border-r min-w-[200px]">Provider</th>
                   {monthDays.map(d => (
                     <th key={d.toString()} className="p-2 min-w-[40px] text-center text-xs font-medium text-muted-foreground border-b border-border">
                       {format(d, 'd')}
                       <div className="text-[10px] font-normal opacity-70">{format(d, 'EEEEE')}</div>
                     </th>
                   ))}
                 </tr>
               </thead>
               <tbody>
                 {currentDayState.map(row => { // Note: currentDayState is filtered by specialty but only for *one day*. We need providers list.
                   // Re-getting providers for month view row iteration
                   const providerId = row.providerId;
                   const provider = staff.find(s => s.id === providerId);
                   if (!provider) return null;

                   return (
                     <tr key={providerId} className="hover:bg-accent/5 group">
                        <td className="sticky left-0 z-10 bg-card p-3 border-r border-b text-sm font-medium group-hover:bg-accent/5 group/provider-month relative">
                          <div className="flex justify-between items-center">
                              <div className="truncate w-[150px]">{provider.name}</div>
                              <Button 
                                  variant="ghost" 
                                  size="icon" 
                                  className="h-5 w-5 opacity-0 group-hover/provider-month:opacity-100 transition-opacity"
                                  onClick={(e) => handleStaffEditClick(e, provider.id)}
                              >
                                  <Edit2 className="h-3 w-3" />
                              </Button>
                          </div>
                          <div className="text-xs text-muted-foreground truncate w-[180px]">{provider.specialty}</div>
                        </td>
                        {monthDays.map(d => {
                          const dateStr = format(d, 'yyyy-MM-dd');
                          const key = `${providerId}-${dateStr}`;
                          const cellData = scheduleState[key];
                          
                          // Simple status dot for month view
                          let statusColor = 'bg-gray-200';
                          if (cellData?.am === 'Patient Care' || cellData?.pm === 'Patient Care') statusColor = 'bg-green-500';
                          if (cellData?.am === 'Off' && cellData?.pm === 'Off') statusColor = 'bg-gray-300';
                          
                          return (
                             <td key={dateStr} 
                                 className="border-b border-border p-1 text-center cursor-pointer hover:bg-accent/10"
                                 onClick={() => handleEditClick(providerId, dateStr)}
                             >
                               <div className={`w-3 h-3 rounded-full mx-auto ${statusColor}`} title={`${cellData?.am}/${cellData?.pm}`} />
                             </td>
                          );
                        })}
                     </tr>
                   );
                 })}
               </tbody>
             </table>
          </div>
        )}

        {/* Schedule Edit Dialog */}
        <Dialog open={!!editingSlot} onOpenChange={(open) => !open && setEditingSlot(null)}>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Edit Schedule</DialogTitle>
              <DialogDescription>
                {editingSlot && `Modifying schedule for ${getProviderName(editingSlot.providerId)} on ${editingSlot.date}`}
              </DialogDescription>
            </DialogHeader>
            
            <div className="grid gap-6 py-4">
              <div className="space-y-4">
                <Label className="text-base">AM Shift</Label>
                <RadioGroup value={editAm} onValueChange={setEditAm} className="grid grid-cols-2 gap-4">
                  {['Patient Care', 'Admin', 'Off', 'Meeting'].map((type) => (
                    <div key={`am-${type}`} className="flex items-center space-x-2">
                      <RadioGroupItem value={type} id={`am-${type}`} />
                      <Label htmlFor={`am-${type}`}>{type}</Label>
                    </div>
                  ))}
                </RadioGroup>
              </div>

              <div className="space-y-4">
                <Label className="text-base">PM Shift</Label>
                <RadioGroup value={editPm} onValueChange={setEditPm} className="grid grid-cols-2 gap-4">
                  {['Patient Care', 'Admin', 'Off', 'Meeting'].map((type) => (
                    <div key={`pm-${type}`} className="flex items-center space-x-2">
                      <RadioGroupItem value={type} id={`pm-${type}`} />
                      <Label htmlFor={`pm-${type}`}>{type}</Label>
                    </div>
                  ))}
                </RadioGroup>
              </div>

              {/* LVN Assignments Editor */}
              {editAssignments.length > 0 && (
                <div className="space-y-4 border-t pt-4">
                  <Label className="text-base">Assigned Staff</Label>
                  <div className="space-y-4">
                    {editAssignments.map((assignment) => (
                      <div key={assignment.lvnId} className="border rounded-lg p-3 space-y-3 bg-muted/20">
                        <div className="font-medium flex items-center gap-2">
                          <Badge variant="outline">{getLvnName(assignment.lvnId)}</Badge>
                        </div>
                        
                        <div className="grid grid-cols-2 gap-4">
                          <div className="space-y-2">
                            <Label className="text-xs">Status</Label>
                            <Select 
                              value={assignment.status} 
                              onValueChange={(v: any) => updateAssignment(assignment.lvnId, { status: v })}
                            >
                              <SelectTrigger className="h-8 text-xs">
                                <SelectValue />
                              </SelectTrigger>
                              <SelectContent>
                                <SelectItem value="Active">Active</SelectItem>
                                <SelectItem value="Sick">Sick</SelectItem>
                                <SelectItem value="Vacation">Vacation</SelectItem>
                              </SelectContent>
                            </Select>
                          </div>

                          {assignment.status === 'Active' ? (
                            <div className="space-y-2">
                              <Label className="text-xs">Clinic / Override</Label>
                              <Select 
                                value={assignment.clinicAssignment || "none"} 
                                onValueChange={(v) => updateAssignment(assignment.lvnId, { clinicAssignment: v === "none" ? null : v as any })}
                              >
                                <SelectTrigger className="h-8 text-xs">
                                  <SelectValue placeholder="None" />
                                </SelectTrigger>
                                <SelectContent>
                                  <SelectItem value="none">Assigned to Provider</SelectItem>
                                  <SelectItem value="Flu Clinic">Flu Clinic</SelectItem>
                                  <SelectItem value="Retinal AI">Retinal AI</SelectItem>
                                </SelectContent>
                              </Select>
                            </div>
                          ) : (
                             <div className="space-y-2">
                                <Label className="text-xs text-muted-foreground">Coverage</Label>
                                <div className="text-xs text-muted-foreground italic pt-1">
                                  Coverage logic managed automatically
                                </div>
                             </div>
                          )}
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>

            <DialogFooter>
              <Button variant="outline" onClick={() => setEditingSlot(null)}>Cancel</Button>
              <Button onClick={handleSaveEdit}>Save Changes</Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>

        {/* Staff Quick Edit Dialog */}
        <Dialog open={!!editingStaffId} onOpenChange={(open) => !open && setEditingStaffId(null)}>
            <DialogContent>
                <DialogHeader>
                    <DialogTitle>Edit Staff Member</DialogTitle>
                    <DialogDescription>Quick edit for name and specialty</DialogDescription>
                </DialogHeader>
                <div className="grid gap-4 py-4">
                    <div className="grid gap-2">
                        <Label htmlFor="quick-name">Name</Label>
                        <Input 
                            id="quick-name"
                            value={editStaffName} 
                            onChange={(e) => setEditStaffName(e.target.value)} 
                        />
                    </div>
                    <div className="grid gap-2">
                        <Label>Specialty</Label>
                        <Select value={editStaffSpecialty} onValueChange={(v: Specialty) => setEditStaffSpecialty(v)}>
                            <SelectTrigger>
                                <SelectValue />
                            </SelectTrigger>
                            <SelectContent>
                                {SPECIALTIES.map(s => (
                                    <SelectItem key={s} value={s}>{s}</SelectItem>
                                ))}
                            </SelectContent>
                        </Select>
                    </div>
                </div>
                <DialogFooter>
                    <Button variant="outline" onClick={() => setEditingStaffId(null)}>Cancel</Button>
                    <Button onClick={handleStaffSave}>Save Details</Button>
                </DialogFooter>
            </DialogContent>
        </Dialog>

      </div>
    </AppLayout>
  );
}