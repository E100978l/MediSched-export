import { useState } from "react";
import { AppLayout } from "@/components/layout/AppLayout";
import { STAFF, SPECIALTIES } from "@/lib/mockData";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { RefreshCw, AlertTriangle, CheckCircle2, ArrowRight, ArrowLeftRight } from "lucide-react";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Label } from "@/components/ui/label";
import { toast } from "@/hooks/use-toast";

export default function Rotations() {
  const lvns = STAFF.filter(s => s.role === 'LVN');
  const [selectedLvn, setSelectedLvn] = useState<string>("");
  const [targetSpecialty, setTargetSpecialty] = useState<string>("");

  const handleRotation = () => {
    toast({
      title: "Rotation Scheduled",
      description: "Staff member has been scheduled for cross-specialty rotation.",
    });
    setSelectedLvn("");
    setTargetSpecialty("");
  };

  // Helper to get names of providers an LVN is assigned to
  const getAssignedProviderNames = (providerIds?: string[]) => {
      if (!providerIds || providerIds.length === 0) return 'Unassigned';
      return providerIds.map(id => STAFF.find(p => p.id === id)?.name).filter(Boolean).join(', ');
  };

  return (
    <AppLayout>
       <div className="p-8 space-y-6 max-w-7xl mx-auto">
        <div>
          <h2 className="text-3xl font-bold tracking-tight font-heading text-foreground">Quarterly Rotations</h2>
          <p className="text-muted-foreground mt-1">
            Manage LVN specialty rotations and cross-training assignments.
          </p>
        </div>

        <Card className="bg-primary/5 border-primary/20">
          <CardContent className="flex flex-col sm:flex-row items-start sm:items-center justify-between p-6 gap-4">
             <div className="flex items-center gap-4">
               <div className="p-3 bg-primary/10 rounded-full text-primary">
                 <RefreshCw className="w-6 h-6" />
               </div>
               <div>
                 <h3 className="font-bold text-lg">Next Rotation Cycle: Q1 2026</h3>
                 <p className="text-sm text-muted-foreground">Scheduled for January 1st, 2026. 3 LVNs are due for rotation.</p>
               </div>
             </div>
             
             <Dialog>
               <DialogTrigger asChild>
                 <Button className="w-full sm:w-auto">
                   <ArrowLeftRight className="w-4 h-4 mr-2" />
                   Plan New Rotation
                 </Button>
               </DialogTrigger>
               <DialogContent>
                 <DialogHeader>
                   <DialogTitle>Plan Staff Rotation</DialogTitle>
                   <DialogDescription>
                     Move an LVN to a new specialty team. Only eligible cross-trained specialties are shown.
                   </DialogDescription>
                 </DialogHeader>
                 <div className="grid gap-4 py-4">
                   <div className="grid gap-2">
                     <Label>Select LVN</Label>
                     <Select value={selectedLvn} onValueChange={setSelectedLvn}>
                       <SelectTrigger>
                         <SelectValue placeholder="Select staff member..." />
                       </SelectTrigger>
                       <SelectContent>
                         {lvns.map(lvn => (
                           <SelectItem key={lvn.id} value={lvn.id}>{lvn.name} ({lvn.specialty})</SelectItem>
                         ))}
                       </SelectContent>
                     </Select>
                   </div>
                   
                   <div className="grid gap-2">
                     <Label>Target Specialty</Label>
                     <Select value={targetSpecialty} onValueChange={setTargetSpecialty} disabled={!selectedLvn}>
                       <SelectTrigger>
                         <SelectValue placeholder="Select new specialty..." />
                       </SelectTrigger>
                       <SelectContent>
                         {selectedLvn && STAFF.find(s => s.id === selectedLvn)?.crossTrained?.map(spec => (
                           <SelectItem key={spec} value={spec}>{spec}</SelectItem>
                         ))}
                         {selectedLvn && (!STAFF.find(s => s.id === selectedLvn)?.crossTrained?.length) && (
                           <SelectItem value="none" disabled>No eligible specialties</SelectItem>
                         )}
                       </SelectContent>
                     </Select>
                   </div>
                 </div>
                 <DialogFooter>
                   <Button onClick={handleRotation} disabled={!selectedLvn || !targetSpecialty}>Confirm Rotation</Button>
                 </DialogFooter>
               </DialogContent>
             </Dialog>
          </CardContent>
        </Card>

        <div className="grid gap-6">
          <Card>
            <CardHeader>
              <CardTitle>LVN Rotation Status</CardTitle>
              <CardDescription>Current assignments and eligibility for rotation.</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {lvns.map(lvn => (
                  <div key={lvn.id} className="flex flex-col sm:flex-row items-start sm:items-center justify-between p-4 border border-border rounded-lg hover:bg-muted/50 transition-colors gap-4">
                    <div className="flex items-center gap-4">
                      <div className="w-10 h-10 rounded-full bg-secondary flex items-center justify-center font-bold text-sm shrink-0">
                        {lvn.name.split(' ').map(n => n[0]).join('').slice(0, 2)}
                      </div>
                      <div>
                        <div className="font-medium">{lvn.name}</div>
                        <div className="text-xs text-muted-foreground flex flex-wrap items-center gap-2">
                          Current: {lvn.specialty}
                          <span className="text-border hidden sm:inline">|</span>
                          <span className="block sm:inline">Assigned to: {getAssignedProviderNames(lvn.assignedTo)}</span>
                        </div>
                      </div>
                    </div>

                    <div className="flex flex-wrap items-center gap-6 w-full sm:w-auto justify-between sm:justify-end">
                       <div className="text-right hidden md:block">
                          <div className="text-xs font-medium text-muted-foreground uppercase mb-1">Can Rotate To</div>
                          <div className="flex gap-1 justify-end">
                            {lvn.crossTrained?.map(spec => (
                              <Badge key={spec} variant="outline" className="text-[10px] py-0 h-5">
                                {spec.replace('Internal/Family Med', 'IM/FM')}
                              </Badge>
                            ))}
                            {(!lvn.crossTrained || lvn.crossTrained.length === 0) && (
                              <span className="text-xs text-muted-foreground italic">No cross-training</span>
                            )}
                          </div>
                       </div>
                       
                       <div className="w-32 text-right">
                          {lvn.crossTrained && lvn.crossTrained.length > 0 ? (
                            <Badge className="bg-green-500/15 text-green-700 hover:bg-green-500/25 border-green-200">
                              <CheckCircle2 className="w-3 h-3 mr-1" />
                              Eligible
                            </Badge>
                          ) : (
                             <Badge variant="destructive" className="bg-orange-500/15 text-orange-700 hover:bg-orange-500/25 border-orange-200">
                              <AlertTriangle className="w-3 h-3 mr-1" />
                              Needs Training
                            </Badge>
                          )}
                       </div>

                       <Button variant="ghost" size="icon">
                         <ArrowRight className="w-4 h-4" />
                       </Button>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </AppLayout>
  );
}
