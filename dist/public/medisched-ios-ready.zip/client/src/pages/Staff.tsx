import { useState } from "react";
import { AppLayout } from "@/components/layout/AppLayout";
import { useStaff } from "@/lib/store";
import { SPECIALTIES, StaffMember, StaffType, Specialty } from "@/lib/mockData";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Search, UserPlus, Lock, Edit2, Trash2, Plus, Check } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { ScrollArea } from "@/components/ui/scroll-area";

export default function Staff() {
  const { staff, updateStaffMember, addStaffMember, deleteStaffMember } = useStaff();
  const [searchQuery, setSearchQuery] = useState("");
  
  // Edit State
  const [editingId, setEditingId] = useState<string | null>(null);
  const [editName, setEditName] = useState("");
  const [editSpecialty, setEditSpecialty] = useState<Specialty>(SPECIALTIES[0]);
  // For LVNs: assigned Providers
  const [editAssignedTo, setEditAssignedTo] = useState<string[]>([]);
  // For LVNs: cross-trained specialties
  const [editCrossTrained, setEditCrossTrained] = useState<Specialty[]>([]);
  // For Providers: assigned LVNs (derived/managed via LVN update logic)
  const [editProviderAssignedLvns, setEditProviderAssignedLvns] = useState<string[]>([]);

  // Add State
  const [isAddOpen, setIsAddOpen] = useState(false);
  const [newName, setNewName] = useState("");
  const [newRole, setNewRole] = useState<StaffType>("LVN");
  const [newSpecialty, setNewSpecialty] = useState<Specialty>(SPECIALTIES[0]);

  // Helper to get names of providers an LVN is assigned to
  const getAssignedProviderNames = (providerIds?: string[]) => {
      if (!providerIds || providerIds.length === 0) return 'Unassigned';
      return providerIds.map(id => staff.find(p => p.id === id)?.name).filter(Boolean).join(', ');
  };

  const filteredStaff = staff.filter(s => 
    s.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    s.role.toLowerCase().includes(searchQuery.toLowerCase()) ||
    s.specialty.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const handleEditOpen = (staffMember: StaffMember) => {
    setEditingId(staffMember.id);
    setEditName(staffMember.name);
    setEditSpecialty(staffMember.specialty);

    if (staffMember.role === 'LVN') {
      setEditAssignedTo(staffMember.assignedTo || []);
      setEditCrossTrained(staffMember.crossTrained || []);
    } else if (['MD', 'DO', 'NP', 'PA'].includes(staffMember.role)) {
      // Find LVNs assigned to this provider
      const assignedLvns = staff.filter(s => s.role === 'LVN' && s.assignedTo?.includes(staffMember.id)).map(s => s.id);
      setEditProviderAssignedLvns(assignedLvns);
    }
  };

  const handleSave = () => {
    if (editingId && editName.trim()) {
      const member = staff.find(s => s.id === editingId);
      if (!member) return;

      const updatedMember = { ...member, name: editName, specialty: editSpecialty };

      if (member.role === 'LVN') {
         // Update LVN assignment directly
         updatedMember.assignedTo = editAssignedTo;
         updatedMember.crossTrained = editCrossTrained;
         updateStaffMember(updatedMember);
      } else {
         // Provider update is tricky because assignments are stored on LVNs
         // Update the provider first
         updateStaffMember(updatedMember);
         
         // Now update related LVNs
         // 1. Add this provider to newly checked LVNs
         staff.filter(s => s.role === 'LVN' && editProviderAssignedLvns.includes(s.id) && !s.assignedTo?.includes(editingId))
              .forEach(lvn => {
                  updateStaffMember({
                      ...lvn,
                      assignedTo: [...(lvn.assignedTo || []), editingId]
                  });
              });

         // 2. Remove this provider from unchecked LVNs
         staff.filter(s => s.role === 'LVN' && !editProviderAssignedLvns.includes(s.id) && s.assignedTo?.includes(editingId))
              .forEach(lvn => {
                  updateStaffMember({
                      ...lvn,
                      assignedTo: lvn.assignedTo?.filter(pid => pid !== editingId) || []
                  });
              });
      }

      setEditingId(null);
      setEditName("");
      setEditSpecialty(SPECIALTIES[0]);
      setEditAssignedTo([]);
      setEditCrossTrained([]);
      setEditProviderAssignedLvns([]);
    }
  };

  const toggleAssignedProvider = (providerId: string) => {
    setEditAssignedTo(prev => 
      prev.includes(providerId) 
        ? prev.filter(id => id !== providerId)
        : [...prev, providerId]
    );
  };

  const toggleProviderLvn = (lvnId: string) => {
    setEditProviderAssignedLvns(prev => 
      prev.includes(lvnId)
        ? prev.filter(id => id !== lvnId)
        : [...prev, lvnId]
    );
  };

  const toggleCrossTrained = (specialty: Specialty) => {
    setEditCrossTrained(prev => 
      prev.includes(specialty)
        ? prev.filter(s => s !== specialty)
        : [...prev, specialty]
    );
  };

  const handleDeleteStaff = (id: string) => {
    deleteStaffMember(id);
    setEditingId(null);
  };

  const handleAddStaff = () => {
    if (newName.trim()) {
      const newId = `new-${Date.now()}`;
      const newStaffMember: StaffMember = {
        id: newId,
        name: newName,
        role: newRole,
        specialty: newSpecialty,
        crossTrained: newRole === 'LVN' ? [] : undefined,
        assignedTo: newRole === 'LVN' ? [] : undefined
      };
      
      addStaffMember(newStaffMember);
      setIsAddOpen(false);
      setNewName("");
      setNewRole("LVN");
      setNewSpecialty(SPECIALTIES[0]);
    }
  };

  // Get all providers for the LVN assignment list
  const allProviders = staff.filter(s => ['MD', 'DO', 'NP', 'PA'].includes(s.role));
  // Get all LVNs for the Provider assignment list
  const allLvns = staff.filter(s => s.role === 'LVN');

  return (
    <AppLayout>
       <div className="p-8 space-y-6 max-w-7xl mx-auto">
        <div className="flex justify-between items-center">
          <div>
            <h2 className="text-3xl font-bold tracking-tight font-heading text-foreground">Staff & Assignments</h2>
            <p className="text-muted-foreground mt-1">
              Directory of all providers, nurses, and support staff.
            </p>
          </div>
          
          <Dialog open={isAddOpen} onOpenChange={setIsAddOpen}>
            <DialogTrigger asChild>
              <Button>
                <UserPlus className="w-4 h-4 mr-2" />
                Add Staff
              </Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>Add New Staff Member</DialogTitle>
                <DialogDescription>
                  Create a new provider or nurse profile.
                </DialogDescription>
              </DialogHeader>
              <div className="grid gap-4 py-4">
                <div className="grid gap-2">
                  <Label htmlFor="new-name">Name</Label>
                  <Input 
                    id="new-name"
                    value={newName}
                    onChange={(e) => setNewName(e.target.value)}
                    placeholder="e.g. Nurse Jane Doe"
                  />
                </div>
                <div className="grid gap-2">
                  <Label htmlFor="new-role">Role</Label>
                  <Select value={newRole} onValueChange={(v: StaffType) => setNewRole(v)}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select role" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="MD">MD</SelectItem>
                      <SelectItem value="DO">DO</SelectItem>
                      <SelectItem value="NP">NP</SelectItem>
                      <SelectItem value="PA">PA</SelectItem>
                      <SelectItem value="LVN">LVN</SelectItem>
                      <SelectItem value="RN">RN</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="grid gap-2">
                  <Label htmlFor="new-specialty">Specialty</Label>
                  <Select value={newSpecialty} onValueChange={(v: Specialty) => setNewSpecialty(v)}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select specialty" />
                    </SelectTrigger>
                    <SelectContent>
                      {SPECIALTIES.map(spec => (
                        <SelectItem key={spec} value={spec}>{spec}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>
              <DialogFooter>
                <Button variant="outline" onClick={() => setIsAddOpen(false)}>Cancel</Button>
                <Button onClick={handleAddStaff}>Create Staff</Button>
              </DialogFooter>
            </DialogContent>
          </Dialog>
        </div>

        <div className="flex items-center gap-4 mb-6">
          <div className="relative flex-1 max-w-md">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input 
              placeholder="Search staff by name or role..." 
              className="pl-10"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
            />
          </div>
        </div>

        <div className="grid gap-6 md:grid-cols-2 xl:grid-cols-3">
          {filteredStaff.map((staffMember) => (
            <Card key={staffMember.id} className="overflow-hidden hover:shadow-md transition-shadow group">
              <CardHeader className="border-b border-border/50 bg-muted/20 pb-4">
                <div className="flex justify-between items-start gap-2">
                  <div className="flex-1">
                    <CardTitle className="text-lg font-medium">{staffMember.name}</CardTitle>
                    <div className="text-sm text-muted-foreground mt-1 flex items-center gap-2">
                      <Badge variant="outline" className="bg-background">{staffMember.role}</Badge>
                      <span>{staffMember.specialty}</span>
                    </div>
                  </div>
                  <Dialog open={editingId === staffMember.id} onOpenChange={(open) => !open && setEditingId(null)}>
                    <DialogTrigger asChild>
                      <Button 
                        variant="ghost" 
                        size="icon" 
                        className="h-8 w-8 opacity-0 group-hover:opacity-100 transition-opacity"
                        onClick={() => handleEditOpen(staffMember)}
                      >
                        <Edit2 className="h-4 w-4" />
                      </Button>
                    </DialogTrigger>
                    <DialogContent className="max-w-md">
                      <DialogHeader>
                        <DialogTitle>Edit Staff</DialogTitle>
                        <DialogDescription>
                          Update details for {staffMember.name}
                        </DialogDescription>
                      </DialogHeader>
                      <div className="grid gap-6 py-4">
                        <div className="grid gap-2">
                          <Label htmlFor="name">Name</Label>
                          <Input 
                            id="name"
                            value={editName}
                            onChange={(e) => setEditName(e.target.value)}
                            placeholder="Enter name..."
                          />
                        </div>

                        <div className="grid gap-2">
                           <Label>Specialty</Label>
                           <Select value={editSpecialty} onValueChange={(v: Specialty) => setEditSpecialty(v)}>
                             <SelectTrigger>
                               <SelectValue placeholder="Select specialty" />
                             </SelectTrigger>
                             <SelectContent>
                               {SPECIALTIES.map(spec => (
                                 <SelectItem key={spec} value={spec}>{spec}</SelectItem>
                               ))}
                             </SelectContent>
                           </Select>
                        </div>

                        {/* LVN Edit View: Select Providers */}
                        {staffMember.role === 'LVN' && (
                          <>
                            <div className="grid gap-2">
                              <Label>Assigned Providers</Label>
                              <ScrollArea className="h-[150px] border rounded-md p-4">
                                <div className="space-y-4">
                                  {allProviders.map(provider => (
                                    <div key={provider.id} className="flex items-center space-x-2">
                                      <Checkbox 
                                        id={`assign-${provider.id}`} 
                                        checked={editAssignedTo.includes(provider.id)}
                                        onCheckedChange={() => toggleAssignedProvider(provider.id)}
                                      />
                                      <div className="grid gap-1.5 leading-none">
                                        <label
                                          htmlFor={`assign-${provider.id}`}
                                          className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
                                        >
                                          {provider.name}
                                        </label>
                                        <p className="text-xs text-muted-foreground">
                                          {provider.specialty}
                                        </p>
                                      </div>
                                    </div>
                                  ))}
                                </div>
                              </ScrollArea>
                            </div>

                            <div className="grid gap-2">
                              <Label>Cross-Trained Specialties</Label>
                              <ScrollArea className="h-[150px] border rounded-md p-4">
                                <div className="space-y-4">
                                  {SPECIALTIES.map(spec => (
                                    <div key={spec} className="flex items-center space-x-2">
                                      <Checkbox 
                                        id={`cross-${spec}`} 
                                        checked={editCrossTrained.includes(spec)}
                                        onCheckedChange={() => toggleCrossTrained(spec)}
                                      />
                                      <label
                                        htmlFor={`cross-${spec}`}
                                        className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
                                      >
                                        {spec}
                                      </label>
                                    </div>
                                  ))}
                                </div>
                              </ScrollArea>
                            </div>
                          </>
                        )}

                        {/* Provider Edit View: Select LVNs */}
                        {['MD', 'DO', 'NP', 'PA'].includes(staffMember.role) && (
                          <div className="grid gap-2">
                            <Label>Assigned LVNs</Label>
                            <ScrollArea className="h-[200px] border rounded-md p-4">
                              <div className="space-y-4">
                                {allLvns.map(lvn => (
                                  <div key={lvn.id} className="flex items-center space-x-2">
                                    <Checkbox 
                                      id={`lvn-${lvn.id}`} 
                                      checked={editProviderAssignedLvns.includes(lvn.id)}
                                      onCheckedChange={() => toggleProviderLvn(lvn.id)}
                                    />
                                    <div className="grid gap-1.5 leading-none">
                                      <label
                                        htmlFor={`lvn-${lvn.id}`}
                                        className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
                                      >
                                        {lvn.name}
                                      </label>
                                      <p className="text-xs text-muted-foreground">
                                        {lvn.specialty}
                                      </p>
                                    </div>
                                  </div>
                                ))}
                              </div>
                            </ScrollArea>
                          </div>
                        )}

                      </div>
                      <DialogFooter className="flex justify-between sm:justify-between">
                        <Button variant="destructive" onClick={() => handleDeleteStaff(staffMember.id)}>
                          <Trash2 className="w-4 h-4 mr-2" />
                          Delete
                        </Button>
                        <div className="flex gap-2">
                          <Button variant="outline" onClick={() => setEditingId(null)}>Cancel</Button>
                          <Button onClick={handleSave}>Save Changes</Button>
                        </div>
                      </DialogFooter>
                    </DialogContent>
                  </Dialog>
                </div>
              </CardHeader>
              <CardContent className="pt-4 space-y-3">
                {staffMember.role === 'LVN' && (
                  <>
                    <div className="space-y-1">
                      <div className="flex items-center justify-between">
                         <div className="text-xs font-medium text-muted-foreground uppercase tracking-wider">Assigned To</div>
                         {(staffMember.specialty === 'Internal/Family Med (Met Home 1)' || staffMember.specialty === 'Internal/Family Med (Met Home 2)') && (
                           <TooltipProvider>
                             <Tooltip>
                               <TooltipTrigger>
                                 <Badge variant="outline" className="text-[10px] px-1 py-0 h-5 bg-blue-50 text-blue-700 border-blue-200 gap-1">
                                   <Lock className="w-3 h-3" /> Quarterly Pair
                                 </Badge>
                               </TooltipTrigger>
                               <TooltipContent>
                                 <p>Stable 1:1 pairing. Changes only for sick/vacation.</p>
                               </TooltipContent>
                             </Tooltip>
                           </TooltipProvider>
                         )}
                      </div>
                      <div className="text-sm font-medium line-clamp-2" title={getAssignedProviderNames(staffMember.assignedTo)}>
                         {getAssignedProviderNames(staffMember.assignedTo)}
                      </div>
                    </div>
                    
                    {staffMember.crossTrained && staffMember.crossTrained.length > 0 && (
                      <div className="space-y-1">
                        <div className="text-xs font-medium text-muted-foreground uppercase tracking-wider">Cross Trained</div>
                        <div className="flex flex-wrap gap-1">
                          {staffMember.crossTrained.map(spec => (
                            <Badge key={spec} variant="secondary" className="text-xs font-normal">
                              {spec}
                            </Badge>
                          ))}
                        </div>
                      </div>
                    )}
                  </>
                )}

                {(staffMember.role === 'MD' || staffMember.role === 'DO' || staffMember.role === 'NP') && (
                   <div className="flex items-center justify-between text-sm pt-2">
                      <span className="text-muted-foreground">Weekly Hours</span>
                      <span className="font-medium">32.0</span>
                   </div>
                )}
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </AppLayout>
  );
}
