import { AppLayout } from "@/components/layout/AppLayout";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { STAFF, SPECIALTIES } from "@/lib/mockData";
import { 
  Users, 
  CalendarCheck, 
  AlertCircle, 
  TrendingUp 
} from "lucide-react";

export default function Dashboard() {
  // Simple counts
  const providerCount = STAFF.filter(s => ['MD', 'DO', 'NP', 'PA'].includes(s.role)).length;
  const lvnCount = STAFF.filter(s => s.role === 'LVN').length;
  const rnCount = STAFF.filter(s => s.role === 'RN').length;

  return (
    <AppLayout>
      <div className="p-8 space-y-8 max-w-7xl mx-auto">
        <div>
          <h2 className="text-3xl font-bold tracking-tight font-heading text-foreground">Dashboard</h2>
          <p className="text-muted-foreground mt-1">
            Overview of clinic staffing, coverage, and rotation status.
          </p>
        </div>

        {/* Stats Grid */}
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Total Staff</CardTitle>
              <Users className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{STAFF.length}</div>
              <p className="text-xs text-muted-foreground">
                {providerCount} Providers, {lvnCount} LVNs
              </p>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Today's Coverage</CardTitle>
              <CalendarCheck className="h-4 w-4 text-primary" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-primary">92%</div>
              <p className="text-xs text-muted-foreground">
                2 providers off today
              </p>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Pending Rotations</CardTitle>
              <TrendingUp className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">3</div>
              <p className="text-xs text-muted-foreground">
                Due for quarterly rotation
              </p>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Gaps</CardTitle>
              <AlertCircle className="h-4 w-4 text-destructive" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-destructive">1</div>
              <p className="text-xs text-muted-foreground">
                Uncovered PM shift in Peds
              </p>
            </CardContent>
          </Card>
        </div>

        {/* Specialty Breakdown */}
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
          <Card className="col-span-2">
            <CardHeader>
              <CardTitle>Staffing by Specialty</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {SPECIALTIES.map(spec => {
                   const count = STAFF.filter(s => s.specialty === spec).length;
                   return (
                     <div key={spec} className="flex items-center">
                       <div className="w-48 text-sm font-medium text-muted-foreground truncate">{spec}</div>
                       <div className="flex-1 h-2 bg-secondary rounded-full overflow-hidden ml-2">
                         <div 
                           className="h-full bg-primary rounded-full" 
                           style={{ width: `${(count / 10) * 100}%` }} // Mock percentage
                         />
                       </div>
                       <div className="ml-4 text-sm font-bold w-8 text-right">{count}</div>
                     </div>
                   )
                })}
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Quarterly Rotation Status</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="p-4 border border-border rounded-lg bg-accent/10">
                  <div className="text-sm font-medium mb-1">Current Cycle</div>
                  <div className="text-2xl font-bold text-primary">Q4 2025</div>
                  <div className="text-xs text-muted-foreground mt-1">Ends Dec 31</div>
                </div>
                
                <div className="space-y-2">
                  <div className="flex justify-between text-sm">
                    <span>Cross-Training Compliance</span>
                    <span className="font-bold">85%</span>
                  </div>
                  <div className="h-2 bg-secondary rounded-full overflow-hidden">
                    <div className="h-full bg-green-500 w-[85%]" />
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </AppLayout>
  );
}
